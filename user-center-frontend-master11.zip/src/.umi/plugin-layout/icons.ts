// @ts-nocheck

  import SmileOutlined from '@ant-design/icons/es/icons/SmileOutlined';
import CrownOutlined from '@ant-design/icons/es/icons/CrownOutlined';
import TableOutlined from '@ant-design/icons/es/icons/TableOutlined'
  export default {
    SmileOutlined,
CrownOutlined,
TableOutlined
  }