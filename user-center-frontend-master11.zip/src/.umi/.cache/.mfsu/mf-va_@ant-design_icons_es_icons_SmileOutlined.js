import _ from '@ant-design/icons/es/icons/SmileOutlined';
export default _;
