(self["webpackChunkant_design_pro"] = self["webpackChunkant_design_pro"] || []).push([["mf-dep_src_umi_cache_mfsu_mf-va_antd_es_message_js"],{

/***/ "./src/.umi/.cache/.mfsu/mf-va_antd_es_message.js":
/*!********************************************************!*\
  !*** ./src/.umi/.cache/.mfsu/mf-va_antd_es_message.js ***!
  \********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "attachTypeApi": function() { return /* reexport safe */ D_repo_user_center_frontend_master_node_modules_antd_es_message__WEBPACK_IMPORTED_MODULE_0__.attachTypeApi; },
/* harmony export */   "getInstance": function() { return /* reexport safe */ D_repo_user_center_frontend_master_node_modules_antd_es_message__WEBPACK_IMPORTED_MODULE_0__.getInstance; },
/* harmony export */   "getKeyThenIncreaseKey": function() { return /* reexport safe */ D_repo_user_center_frontend_master_node_modules_antd_es_message__WEBPACK_IMPORTED_MODULE_0__.getKeyThenIncreaseKey; },
/* harmony export */   "typeList": function() { return /* reexport safe */ D_repo_user_center_frontend_master_node_modules_antd_es_message__WEBPACK_IMPORTED_MODULE_0__.typeList; }
/* harmony export */ });
/* harmony import */ var D_repo_user_center_frontend_master_node_modules_antd_es_message__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/antd/es/message */ "./node_modules/antd/es/message/index.js");

/* harmony default export */ __webpack_exports__["default"] = (D_repo_user_center_frontend_master_node_modules_antd_es_message__WEBPACK_IMPORTED_MODULE_0__.default);



/***/ })

}]);