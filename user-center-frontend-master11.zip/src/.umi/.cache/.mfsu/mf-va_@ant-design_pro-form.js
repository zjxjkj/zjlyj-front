import _ from '@ant-design/pro-form';
export default _;
export * from '@ant-design/pro-form';
