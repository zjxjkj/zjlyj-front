import _ from '@ant-design/icons/SmileOutlined';
export default _;
