import _ from 'D:/repo/user-center-frontend-master/node_modules/antd/es/message';
export default _;
export * from 'D:/repo/user-center-frontend-master/node_modules/antd/es/message';
