import _ from 'D:/repo/user-center-frontend-master/node_modules/dumi-theme-default/es/builtins/Table.js';
export default _;
