import 'D:/repo/user-center-frontend-master/node_modules/antd/es/avatar/style';
