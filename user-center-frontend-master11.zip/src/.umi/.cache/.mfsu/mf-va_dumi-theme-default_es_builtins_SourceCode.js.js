import _ from 'D:/repo/user-center-frontend-master/node_modules/dumi-theme-default/es/builtins/SourceCode.js';
export default _;
