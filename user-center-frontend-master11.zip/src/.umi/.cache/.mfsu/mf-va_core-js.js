import _ from 'D:/repo/user-center-frontend-master/node_modules/core-js';
export default _;
export * from 'D:/repo/user-center-frontend-master/node_modules/core-js';
