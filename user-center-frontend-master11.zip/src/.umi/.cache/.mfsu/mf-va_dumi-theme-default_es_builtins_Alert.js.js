import _ from 'D:/repo/user-center-frontend-master/node_modules/dumi-theme-default/es/builtins/Alert.js';
export default _;
