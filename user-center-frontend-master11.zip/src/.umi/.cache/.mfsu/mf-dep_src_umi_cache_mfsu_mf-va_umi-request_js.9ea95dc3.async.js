(self["webpackChunkant_design_pro"] = self["webpackChunkant_design_pro"] || []).push([["mf-dep_src_umi_cache_mfsu_mf-va_umi-request_js"],{

/***/ "./src/.umi/.cache/.mfsu/mf-va_umi-request.js":
/*!****************************************************!*\
  !*** ./src/.umi/.cache/.mfsu/mf-va_umi-request.js ***!
  \****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Onion": function() { return /* reexport safe */ umi_request__WEBPACK_IMPORTED_MODULE_0__.Onion; },
/* harmony export */   "RequestError": function() { return /* reexport safe */ umi_request__WEBPACK_IMPORTED_MODULE_0__.RequestError; },
/* harmony export */   "ResponseError": function() { return /* reexport safe */ umi_request__WEBPACK_IMPORTED_MODULE_0__.ResponseError; },
/* harmony export */   "extend": function() { return /* reexport safe */ umi_request__WEBPACK_IMPORTED_MODULE_0__.extend; },
/* harmony export */   "fetch": function() { return /* reexport safe */ umi_request__WEBPACK_IMPORTED_MODULE_0__.fetch; }
/* harmony export */ });
/* harmony import */ var umi_request__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! umi-request */ "./node_modules/umi-request/dist/index.esm.js");

/* harmony default export */ __webpack_exports__["default"] = (umi_request__WEBPACK_IMPORTED_MODULE_0__.default);



/***/ }),

/***/ "?4f7e":
/*!********************************!*\
  !*** ./util.inspect (ignored) ***!
  \********************************/
/***/ (function() {

/* (ignored) */

/***/ })

}]);