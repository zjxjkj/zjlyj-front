import _ from 'umi-request';
export default _;
export * from 'umi-request';
