import _ from 'D:/repo/user-center-frontend-master/node_modules/umi/node_modules/regenerator-runtime/runtime.js';
export default _;
export * from 'D:/repo/user-center-frontend-master/node_modules/umi/node_modules/regenerator-runtime/runtime.js';
