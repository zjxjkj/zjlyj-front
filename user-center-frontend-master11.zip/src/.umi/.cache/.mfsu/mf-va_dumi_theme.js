export * from 'D:/repo/user-center-frontend-master/node_modules/@umijs/preset-dumi/lib/theme';
