import _ from 'D:/repo/user-center-frontend-master/node_modules/antd/es/spin';
export default _;
